

void sift_test1B();
int main() {
    sift_test1B();

    return 0;
}
